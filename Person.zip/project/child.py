from project.person import Person


class Child(Person):
    pass
